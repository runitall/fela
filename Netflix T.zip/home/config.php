<?php
// setting scama
$yourmail  = "";  // your email 
$namerand = "rzlt";  // name for file rzult *
$pass = "123345"; // pass admin panel
$botToken="ttoooooooooooooooooooook"; // token bot telegram
$chatId="-ennnnnnnnnnn";  // chatId telegram

?>