put your config in
/net/system/setting.php

put your config for log in
/email.php

put your info config.php